import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JPanel;
import javax.swing.JTextArea;

import java.awt.Font;

import javax.swing.JSpinner;

import java.awt.Color;

import javax.swing.JTextPane;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


public class Buy {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void BuyButtn() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Buy window = new Buy();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Buy() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(00, 00, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(878, 89, 164, 164);
		frame.getContentPane().add(panel_2);
		
		JTextArea txtrQuantity = new JTextArea();
		txtrQuantity.setFont(new Font("Calibri", Font.PLAIN, 25));
		txtrQuantity.setText("Polo Shirt");
		txtrQuantity.setBounds(596, 24, 102, 30);
		frame.getContentPane().add(txtrQuantity);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(281, 264, 41, 30);
		frame.getContentPane().add(spinner);
		
		JButton btnNewButton_1 = new JButton("Place Order");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			PlaceOrder nw = new PlaceOrder();
					nw.PlcOrdrButtn(); 
					frame.dispose();
			}
		});
		btnNewButton_1.setBounds(1124, 512, 137, 50);
		frame.getContentPane().add(btnNewButton_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(572, 89, 164, 164);
		frame.getContentPane().add(panel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(281, 89, 164, 164);
		frame.getContentPane().add(panel);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setBounds(572, 264, 41, 30);
		frame.getContentPane().add(spinner_1);
		
		JSpinner spinner_2 = new JSpinner();
		spinner_2.setBounds(878, 264, 41, 30);
		frame.getContentPane().add(spinner_2);
		
		JTextArea txtrPants = new JTextArea();
		txtrPants.setFont(new Font("Calibri", Font.PLAIN, 25));
		txtrPants.setText("Pants");
		txtrPants.setBounds(621, 334, 60, 35);
		frame.getContentPane().add(txtrPants);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "2XS", "XS", "S", "M", "L", "XL", "2XL", "3XL", "6XL"}));
		comboBox.setToolTipText("");
		comboBox.setBounds(332, 264, 113, 30);
		frame.getContentPane().add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "2XS", "XS", "S", "M", "L", "XL", "2XL", "3XL", "6XL"}));
		comboBox_1.setBounds(621, 264, 115, 30);
		frame.getContentPane().add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "2XS", "XS", "S", "M", "L", "XL", "2XL", "3XL", "6XL"}));
		comboBox_2.setBounds(929, 264, 113, 30);
		frame.getContentPane().add(comboBox_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.LIGHT_GRAY);
		panel_3.setBounds(281, 398, 164, 164);
		frame.getContentPane().add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.LIGHT_GRAY);
		panel_4.setBounds(572, 398, 164, 164);
		frame.getContentPane().add(panel_4);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.LIGHT_GRAY);
		panel_5.setBounds(878, 398, 164, 164);
		frame.getContentPane().add(panel_5);
		
		JSpinner spinner_3 = new JSpinner();
		spinner_3.setBounds(281, 573, 41, 30);
		frame.getContentPane().add(spinner_3);
		
		JSpinner spinner_4 = new JSpinner();
		spinner_4.setBounds(572, 573, 41, 30);
		frame.getContentPane().add(spinner_4);
		
		JSpinner spinner_5 = new JSpinner();
		spinner_5.setBounds(878, 573, 41, 30);
		frame.getContentPane().add(spinner_5);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "S", "M", "L", "XL"}));
		comboBox_3.setBounds(332, 573, 113, 30);
		frame.getContentPane().add(comboBox_3);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "S", "M", "L", "XL"}));
		comboBox_4.setBounds(624, 572, 113, 30);
		frame.getContentPane().add(comboBox_4);
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "S", "M", "L", "XL"}));
		comboBox_5.setBounds(929, 573, 113, 30);
		frame.getContentPane().add(comboBox_5);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Welcome nw = new Welcome ();
				nw.WlcmBttn();
				frame.dispose();
			}
		});
		btnNewButton.setBounds(22, 33, 89, 23);
		frame.getContentPane().add(btnNewButton);
	}
}
