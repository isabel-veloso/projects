import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class CheckUniformStocks {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Launch the application.
	 */
	public static void ChckStcksButtn (){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CheckUniformStocks window = new CheckUniformStocks();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CheckUniformStocks() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(281, 89, 164, 164);
		frame.getContentPane().add(panel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(572, 89, 164, 164);
		frame.getContentPane().add(panel_1);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.LIGHT_GRAY);
		panel_2.setBounds(878, 89, 164, 164);
		frame.getContentPane().add(panel_2);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(Color.LIGHT_GRAY);
		panel_3.setBounds(281, 398, 164, 164);
		frame.getContentPane().add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(Color.LIGHT_GRAY);
		panel_4.setBounds(572, 398, 164, 164);
		frame.getContentPane().add(panel_4);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(Color.LIGHT_GRAY);
		panel_5.setBounds(878, 398, 164, 164);
		frame.getContentPane().add(panel_5);
		
		textField = new JTextField();
		textField.setBounds(281, 264, 41, 30);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "2XS", "XS", "S", "M", "L", "XL", "2XL", "3XL", "6XL"}));
		comboBox.setBounds(332, 264, 113, 30);
		frame.getContentPane().add(comboBox);
		
		textField_1 = new JTextField();
		textField_1.setBounds(572, 264, 41, 30);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(878, 264, 41, 30);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(281, 573, 41, 30);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(572, 573, 41, 30);
		frame.getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setText("");
		textField_5.setBounds(878, 573, 41, 30);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "2XS", "XS", "S", "M", "L", "XL", "2XL", "3XL", "6XL"}));
		comboBox_1.setBounds(620, 264, 113, 30);
		frame.getContentPane().add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "2XS", "XS", "S", "M", "L", "XL", "2XL", "3XL", "6XL"}));
		comboBox_2.setBounds(927, 264, 113, 30);
		frame.getContentPane().add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox();
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "S", "M", "L", "XL"}));
		comboBox_3.setBounds(332, 573, 113, 30);
		frame.getContentPane().add(comboBox_3);
		
		JComboBox comboBox_4 = new JComboBox();
		comboBox_4.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "S", "M", "L", "XL"}));
		comboBox_4.setBounds(624, 573, 113, 30);
		frame.getContentPane().add(comboBox_4);
		
		JComboBox comboBox_5 = new JComboBox();
		comboBox_5.setModel(new DefaultComboBoxModel(new String[] {"-Choose Size-", "S", "M", "L", "XL"}));
		comboBox_5.setBounds(929, 573, 113, 30);
		frame.getContentPane().add(comboBox_5);
		
		JTextArea txtrPoloShirt = new JTextArea();
		txtrPoloShirt.setFont(new Font("Calibri", Font.PLAIN, 25));
		txtrPoloShirt.setText("Polo Shirt");
		txtrPoloShirt.setBounds(600, 34, 105, 30);
		frame.getContentPane().add(txtrPoloShirt);
		
		JTextArea txtrPants = new JTextArea();
		txtrPants.setText("Pants");
		txtrPants.setFont(new Font("Calibri", Font.PLAIN, 25));
		txtrPants.setBounds(629, 337, 60, 30);
		frame.getContentPane().add(txtrPants);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Welcome nw = new Welcome ();
				nw.WlcmBttn();
				frame.dispose();
						
			}
		});
		btnBack.setBounds(24, 43, 79, 23);
		frame.getContentPane().add(btnBack);
		
		JButton btnNewButton = new JButton("Save Changes");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(1150, 612, 123, 51);
		frame.getContentPane().add(btnNewButton);
	}
}
