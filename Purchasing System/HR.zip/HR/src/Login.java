import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;


public class Login {

	private JFrame frame;
	private JTextField txtUsername;
	private JPasswordField pwdPassword;
	private JLabel lblNewHlabfghel;
	

	/**
	 * Launch the application.
	 */
	public static void LgnBttn(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(00, 00, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(505, 295, 351, 386);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtUsername.setText("Username");
		txtUsername.setBounds(41, 118, 272, 38);
		panel.add(txtUsername);
		txtUsername.setColumns(10);
		
		JButton btnLogin = new JButton("Log-in");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Welcome nw = new Welcome();
				nw.WlcmBttn();
				frame.dispose();
				
				
			}
		});
		btnLogin.setFont(new Font("Calibri", Font.BOLD, 14));
		btnLogin.setBounds(111, 274, 119, 38);
		panel.add(btnLogin);
		
		pwdPassword = new JPasswordField();
		pwdPassword.setEchoChar('*');
		pwdPassword.setText("Password");
		pwdPassword.setBounds(41, 178, 272, 38);
		panel.add(pwdPassword);
		
		lblNewHlabfghel = new JLabel("");
		lblNewHlabfghel.setForeground(Color.WHITE);
		lblNewHlabfghel.setBackground(Color.WHITE);
		lblNewHlabfghel.setIcon(new ImageIcon("C:\\Users\\TOTON\\workspace\\HR\\images\\Header.PNG"));
		lblNewHlabfghel.setBounds(163, 11, 1001, 238);
		frame.getContentPane().add(lblNewHlabfghel);
		
		
	}

	public void LgnButtn() {
		// TODO Auto-generated method stub
		
	}
}
