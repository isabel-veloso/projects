import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Component;
import javax.swing.Box;


public class Checkout {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void ChckButtn(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Checkout window = new Checkout();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Checkout() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(0, 0, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.control);
		panel.setBounds(25, 28, 1290, 658);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Buy nw = new Buy ();
				nw.BuyButtn();
				frame.dispose();
						
			}
		});
		btnNewButton_1.setBounds(59, 51, 87, 38);
		panel.add(btnNewButton_1);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblQuantity.setHorizontalAlignment(SwingConstants.CENTER);
		lblQuantity.setBounds(224, 133, 75, 44);
		panel.add(lblQuantity);
		
		JTextPane textPane = new JTextPane();
		textPane.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textPane.setText("1");
		textPane.setBounds(246, 210, 22, 20);
		panel.add(textPane);
		
		JTextPane textPane_1 = new JTextPane();
		textPane_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textPane_1.setText("1");
		textPane_1.setBounds(246, 427, 22, 20);
		panel.add(textPane_1);
		
		JLabel lblItem = new JLabel("Item");
		lblItem.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblItem.setHorizontalAlignment(SwingConstants.CENTER);
		lblItem.setBounds(493, 133, 81, 44);
		panel.add(lblItem);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.activeCaptionBorder);
		panel_1.setBounds(391, 196, 87, 87);
		panel.add(panel_1);
		
		JTextPane txtpnWhitePoloShirt = new JTextPane();
		txtpnWhitePoloShirt.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtpnWhitePoloShirt.setText("White Polo Shirt Size: 6XL");
		txtpnWhitePoloShirt.setBounds(505, 210, 118, 44);
		panel.add(txtpnWhitePoloShirt);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(SystemColor.activeCaptionBorder);
		panel_2.setBounds(391, 380, 87, 87);
		panel.add(panel_2);
		
		JTextPane txtpnNavyBluePants = new JTextPane();
		txtpnNavyBluePants.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtpnNavyBluePants.setText("Navy Blue Pants Size: L");
		txtpnNavyBluePants.setBounds(505, 399, 126, 48);
		panel.add(txtpnNavyBluePants);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPrice.setBounds(888, 150, 52, 20);
		panel.add(lblPrice);
		
		JTextPane txtpnPhp = new JTextPane();
		txtpnPhp.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtpnPhp.setText("Php 000.00");
		txtpnPhp.setBounds(864, 210, 87, 20);
		panel.add(txtpnPhp);
		
		JTextPane txtpnPhp_1 = new JTextPane();
		txtpnPhp_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtpnPhp_1.setText("Php 000.00");
		txtpnPhp_1.setBounds(864, 399, 87, 28);
		panel.add(txtpnPhp_1);
		
		JLabel lblTotal = new JLabel("Total:");
		lblTotal.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblTotal.setBounds(771, 472, 46, 14);
		panel.add(lblTotal);
		
		JLabel label = new JLabel("_____________________");
		label.setBounds(837, 427, 153, 14);
		panel.add(label);
		
		JTextPane txtpnPhp_2 = new JTextPane();
		txtpnPhp_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		txtpnPhp_2.setText("Php 0000.00");
		txtpnPhp_2.setBounds(846, 472, 118, 28);
		panel.add(txtpnPhp_2);
		
		JButton btnNewButton = new JButton("CHECKOUT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Note nw = new Note ();
				nw.NoteButtn();
				frame.dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(832, 547, 132, 38);
		panel.add(btnNewButton);
	}
}
