import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;


public class Welcome {

	private JFrame frame;
	private JTextPane txtpnWelcome;
	private JLabel lblAsd;

	/**
	 * Launch the application.
	 */
	public static void WlcmBttn () {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Welcome window = new Welcome();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Welcome() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(00, 0, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Buy Uniform");
		btnNewButton.setFont(new Font("Calibri", Font.BOLD, 25));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Buy nw = new Buy ();
				nw.BuyButtn();
				frame.dispose();
			}
		});
		btnNewButton.setBounds(445, 465, 338, 40);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Check Uniform Stocks");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CheckUniformStocks nw = new CheckUniformStocks ();
				nw.ChckStcksButtn();
				frame.dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Calibri", Font.BOLD, 25));
		btnNewButton_1.setBounds(445, 531, 338, 40);
		frame.getContentPane().add(btnNewButton_1);
		
		txtpnWelcome = new JTextPane();
		txtpnWelcome.setBackground(Color.WHITE);
		txtpnWelcome.setFont(new Font("Arial Black", Font.BOLD, 55));
		txtpnWelcome.setText("Welcome, <user>!");
		txtpnWelcome.setBounds(338, 296, 595, 84);
		frame.getContentPane().add(txtpnWelcome);
		
		lblAsd = new JLabel("");
		lblAsd.setIcon(new ImageIcon("C:\\Users\\TOTON\\workspace\\HR\\images\\Header.PNG"));
		lblAsd.setBounds(163, 11, 1001, 238);
		frame.getContentPane().add(lblAsd);
	}
}
