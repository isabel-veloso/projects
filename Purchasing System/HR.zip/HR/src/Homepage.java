import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;


public class Homepage {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Homepage window = new Homepage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Homepage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(00, 00, 1366, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		
		JButton button1 = new JButton("");
		button1.setForeground(new Color(255, 255, 255));
		button1.setBackground(new Color(255, 255, 255));
		button1.setIcon(new ImageIcon("C:\\Users\\TOTON\\workspace\\HR\\images\\Login.PNG"));
		button1.setBounds(291, 422, 789, 99);
		frame.getContentPane().add(button1);
		
		JLabel label = new JLabel("New label");
		label.setIcon(new ImageIcon("C:\\Users\\TOTON\\workspace\\HR\\images\\Header.PNG"));
		label.setBounds(163, 11, 1001, 238);
		frame.getContentPane().add(label);
		button1.addActionListener(new ActionListener(){

		    public void actionPerformed(ActionEvent arg0) {
		    Login nw = new Login();
		    nw.LgnBttn();
		    	frame.dispose();
		    }
		 
		});
		
		
	}
}
