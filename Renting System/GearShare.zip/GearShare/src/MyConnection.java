import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Sabel
 */
public class MyConnection {
    public static Connection getConnection() {
        Connection con = null;
        try {
            // Define the connection parameters
            String url = "jdbc:mysql://localhost:3306/your_database_name"; // replace with your DB name
            String username = "root"; // MySQL root user
            String password = "your_password"; // replace with your MySQL password

            // Establish the connection
            con = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }
}